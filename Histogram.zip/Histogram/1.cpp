#include <iostream>
#include <fstream>
#include <conio.h>
using namespace std;

void swap(int &x, int &y)
{

    int c;
    c = x;
    x = y;
    y = c;
}

int main()
{
    ifstream read("story.txt");
    char temp = ' ';
    if (read)
    {
        /*char word[20];
        int count=0;
        while(read>>word)
        {
            count++;
        }
        cout<<"Total words are : "<<count<<endl;
        cout<<""
        */

        /*
        char p;
        while(true)
        {
            p = getch();
            cout<<"*";
            if(p=='\r')
                break;
        }
        */

        // cout<<"You have press enter key"<<endl;

        int counts[26] = {0};

        // counting spaces and store value in c
        char letter;
        int sp = 0;
        char alphabate[27] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        while (read.get(letter))
        {
            if (letter == ' ')
                sp++;
            else if (letter >= 'a' && letter <= 'z')
            {
                int index = (int)letter - (int)'a';
                counts[index]++;
            }
            else if (letter >= 'A' && letter <= 'Z')
            {
                int index = (int)letter - (int)'A';
                counts[index]++;
            }
        }
        cout << "Total spaces are : " << sp << endl;

        // SORTING COUNTS ARRAY

        for (int loop = 1; loop <= 26; loop++)
        {
            for (int k = 0; k <= 24; k++)
            {
                if (counts[k] < counts[k + 1])
                {
                    swap(counts[k], counts[k + 1]);

                    temp = alphabate[k];
                    alphabate[k] = alphabate[k + 1];
                    alphabate[k + 1] = temp;
                }
            }
        }

        int number = 26;
        for (int i = 0; i < number; number--)
        {
            for (int j = 0; j < 26; j++)
            {
                if (counts[j] >= number)
                    cout << "   *";
                else
                    cout << "    ";
            }
            cout << endl;
        }
        for (int i = 0; i < 26; i++)
            cout << "   " << (char)(97 + i);
    }
    else
    {
        cerr << "Hi bostron, its not your area." << endl;
    }

    return 0;
}